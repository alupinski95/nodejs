function recurse(){
    recurse();
}
recurse();
//node StackOverflow.js